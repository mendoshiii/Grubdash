module.exports = [
  {
    id: "3c637d011d844ebab1205fef8a7e36ea",
    name: "Broccoli and beetroot stir fry",
    description: "Crunchy stir fry featuring fresh broccoli and beetroot",
    price: 15,
    image_url:
      "https://images.pexels.com/photos/4144234/pexels-photo-4144234.jpeg?h=530&w=350",
  },
  {
    id: "90c3d873684bf381dfab29034b5bba73",
    name: "Falafel and tahini bagel",
    description: "A warm bagel filled with falafel and tahini",
    price: 6,
    image_url:
      "https://images.pexels.com/photos/4560606/pexels-photo-4560606.jpeg?h=530&w=350",
  },
  {
    id: "d351db2b49b69679504652ea1cf38241",
    name: "Dolcelatte and chickpea spaghetti",
    description:
      "Spaghetti topped with a blend of dolcelatte and fresh chickpeas",
    price: 19,
    image_url:
      "https://images.pexels.com/photos/1279330/pexels-photo-1279330.jpeg?h=530&w=350",
  },
];
