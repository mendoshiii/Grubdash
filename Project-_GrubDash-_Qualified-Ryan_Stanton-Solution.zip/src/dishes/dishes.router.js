const router = require("express").Router();

// TODO: Implement the /dishes routes needed to make the tests pass

module.exports = router;
